// GOLDEN MOMENTS — script.js

// Dark mode
const DT = document.querySelector('.btn-dark');
if(localStorage.getItem('gm-dark')==='1') document.body.classList.add('dark');
DT && DT.addEventListener('click',()=>{
  document.body.classList.toggle('dark');
  localStorage.setItem('gm-dark', document.body.classList.contains('dark')?'1':'0');
  DT.textContent = document.body.classList.contains('dark')? '☀️' : '🌙';
});
if(DT && document.body.classList.contains('dark')) DT.textContent='☀️';

// Drawer
const openBtn=document.getElementById('menuBtn');
const drawer=document.getElementById('drawer');
const overlay=document.getElementById('overlay');
const closeBtn=document.getElementById('closeBtn');
const open=()=>{drawer?.classList.add('on');overlay?.classList.add('on');};
const close=()=>{drawer?.classList.remove('on');overlay?.classList.remove('on');};
openBtn?.addEventListener('click',open);
closeBtn?.addEventListener('click',close);
overlay?.addEventListener('click',close);
document.querySelectorAll('.drawer-nav a').forEach(a=>a.addEventListener('click',close));

// Scroll fade
const obs=new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('vis');obs.unobserve(e.target);}});
},{threshold:0.1});
document.querySelectorAll('.fu').forEach(el=>obs.observe(el));

// FAQ
document.querySelectorAll('.faq-item').forEach(item=>{
  item.querySelector('.faq-q')?.addEventListener('click',()=>{
    const open=item.classList.contains('open');
    document.querySelectorAll('.faq-item.open').forEach(i=>i.classList.remove('open'));
    if(!open)item.classList.add('open');
  });
});

// Gallery filter
document.querySelectorAll('.gal-btn').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('.gal-btn').forEach(b=>b.classList.remove('on'));
    btn.classList.add('on');
    const f=btn.dataset.f;
    document.querySelectorAll('.gal-item').forEach(item=>{
      item.style.display=(f==='all'||item.dataset.c===f)?'flex':'none';
    });
  });
});

// Booking form → WhatsApp + Email
const form=document.getElementById('bookForm');
form?.addEventListener('submit',function(e){
  e.preventDefault();
  const g=id=>document.getElementById(id)?.value||'';
  const checks=name=>Array.from(document.querySelectorAll(`input[name="${name}"]:checked`)).map(c=>c.value).join(', ')||'None';
  const radio=name=>document.querySelector(`input[name="${name}"]:checked`)?.value||'';

  const msg=`🎉 *NEW EVENT BOOKING — Golden Moments*\n\n`+
    `👤 *Name:* ${g('f_name')}\n📞 *Phone:* ${g('f_phone')}\n📱 *WhatsApp:* ${g('f_wa')}\n`+
    `✉️ *Email:* ${g('f_email')}\n📍 *Location:* ${g('f_loc')}\n\n`+
    `🎊 *Event Type:* ${g('f_etype')}\n📅 *Date:* ${g('f_date')}\n⏰ *Time:* ${g('f_time')}\n`+
    `🏛️ *Venue:* ${g('f_venue')}\n👥 *Guests:* ${g('f_guests')}\n\n`+
    `🛠️ *Services:* ${checks('svc')}\n🍽️ *Catering:* ${radio('catering')}\n`+
    `💡 *Lighting:* ${g('f_light')}\n📸 *Photography:* ${checks('photo')}\n`+
    `🎭 *Other:* ${checks('other_svc')}\n\n`+
    `💰 *Budget:* ${g('f_budget')}\n📬 *Contact Pref:* ${radio('contact_pref')}\n\n`+
    `💬 *Special Req:* ${g('f_special')}`;

  window.open(`https://wa.me/918276835699?text=${encodeURIComponent(msg)}`,'_blank');

  // Email
  setTimeout(()=>{
    const body=msg.replace(/[*🎉👤📞📱✉️📍🎊📅⏰🏛️👥🛠️🍽️💡📸🎭💰📬💬]/g,'');
    window.location.href=`mailto:sr.goldenmoments@gmail.com?subject=New Event Booking - ${g('f_name')}&body=${encodeURIComponent(body)}`;
  },1000);
});

// Login
document.getElementById('loginForm')?.addEventListener('submit',e=>{
  e.preventDefault();
  alert('Login feature coming soon! Please contact us via WhatsApp at +91 82768 35699');
});
